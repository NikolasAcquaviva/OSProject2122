#ifndef SCHEDULER_H
#define SCHEDULER_H

/**
 * @brief
 *
 */
void scheduler();

#endif
