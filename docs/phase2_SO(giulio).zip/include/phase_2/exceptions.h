/**
 * @file exceptions.h
 * @author Enrico Emiro
 * @author Giulio Billi
 * @brief Header dell'exception handler
 * @date 2022-04-01
 */
#ifndef EXCEPTIONS_H
#define EXCEPTIONS_H

/**
 * @brief
 *
 */
void exceptionHandler();

#endif
