#ifndef INTERRUPTS_H
#define INTERRUPTS_H

/**
 * @brief
 *
 */
void interruptExceptionHandler();

#endif
